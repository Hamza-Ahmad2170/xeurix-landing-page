import XeurixBlog from "@/components/blog/XeurixBlog";
import Blog from "@/components/blog/Blog";

function page() {
  return (
    <main>
      <XeurixBlog />
      <Blog />
    </main>
  );
}

export default page;
