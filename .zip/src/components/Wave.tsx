import "./css/wave.css";

const Wave = () => (
  <div className="WaveWrapper">
    <div className="wave" />
    <div className="wave" />
  </div>
);

export default Wave;
