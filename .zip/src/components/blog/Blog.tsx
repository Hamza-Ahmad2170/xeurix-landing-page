import LatestBlog from "./LatestBlog";

function Blog() {
  return (
    <>
      <LatestBlog />
    </>
  );
}

export default Blog;
